import { StarRatingPipe } from './star-rating.pipe';

describe('StarRatingPipe', () => {
  it('create an instance', () => {
    const pipe = new StarRatingPipe();
    expect(pipe).toBeTruthy();
  });
});
