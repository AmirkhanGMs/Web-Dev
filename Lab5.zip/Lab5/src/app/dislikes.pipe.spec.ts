import { DislikesPipe } from './dislikes.pipe';

describe('DislikesPipe', () => {
  it('create an instance', () => {
    const pipe = new DislikesPipe();
    expect(pipe).toBeTruthy();
  });
});
