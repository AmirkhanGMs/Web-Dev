import { LikesPipe } from './likes.pipe';

describe('LikesPipe', () => {
  it('create an instance', () => {
    const pipe = new LikesPipe();
    expect(pipe).toBeTruthy();
  });
});
