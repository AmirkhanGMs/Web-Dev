let result = (a + b < 4) ? 'Below' : 'Over';
