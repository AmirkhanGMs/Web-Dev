function min(a, b) {
    if (a < b) {
        return a;
    } else {
        return b;
    }
}