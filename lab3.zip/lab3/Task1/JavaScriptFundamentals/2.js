let admin, name;
let ourPlanetName = "Earth";
let currentUserName = "John";

name = "John";

admin = name;

alert( admin );